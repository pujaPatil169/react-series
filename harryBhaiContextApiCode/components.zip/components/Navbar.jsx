import React from 'react'
import Button from './Button'

const Navbar = () => {
  return (
    <>
    <div>
      Navbar
    </div>
    <Button/>
    </>
  )
}

export default Navbar
